
package Dao;

import it.enaip.corso.psms.model.Stuff;

interface StuffDao extends Dao<Stuff,String>{
    
}
